"""Static file server for the tactical board (no-cache, so edits show up immediately).

启动时（绑定端口前）会自动把旧的「三档精度布局」归一化成「两档布局」：
只重命名 <Map>_mid.mfpk → <Map>_high.mfpk、旧 <Map>_high.mfpk 改名 .pre_twotier.bak、
重写 lod.json（high = 旧 mid）并备份原 lod；**不重打包、不删除任何文件**。
已是两档格式时只打印「已是两档格式，跳过」，不修改任何数据。
可用环境变量控制：
  DF_WEB_MAP_ROOT             地图根目录（默认 <这里>/web/map）
  DF_TIER_UPGRADE_BACKUP_ROOT 备份/日志根目录（默认 <这里>/_backup/tier_upgrade_auto）
  DF_SKIP_TIER_UPGRADE=1      关闭启动自动升级
升级失败只打印警告，绝不阻止服务器启动。
"""

from __future__ import annotations

import functools
import http.server
import json
import os
import shutil
import socketserver
import sys
import tempfile
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8777

DEFAULT_WEB_MAP_ROOT = os.path.join(HERE, 'web', 'map')
DEFAULT_TIER_UPGRADE_BACKUP_ROOT = os.path.join(HERE, '_backup', 'tier_upgrade_auto')


def _force_utf8_stdio() -> None:
    """Windows 下 stdout/stderr 被重定向到文件或管道时默认用本地代码页（cp936），
    中文会乱码；统一改成 UTF-8。交互式控制台行为不受影响。"""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding='utf-8', errors='replace',
                               line_buffering=True, write_through=True)
        except Exception:
            pass


def _has_lod_maps(root: str) -> bool:
    if not os.path.isdir(root):
        return False
    for name in os.listdir(root):
        if os.path.isfile(os.path.join(root, name, 'lod.json')):
            return True
    return False


def run_tier_upgrade() -> None:
    """启动钩子：把旧三档精度布局自动升级为两档（幂等；新格式下无动作）。

    任何异常都只打印警告，必须让服务器照常启动。
    """
    if os.environ.get('DF_SKIP_TIER_UPGRADE') == '1':
        print('[tier-upgrade] DF_SKIP_TIER_UPGRADE=1，跳过启动自动升级')
        return
    web_map_root = os.environ.get('DF_WEB_MAP_ROOT') or DEFAULT_WEB_MAP_ROOT
    backup_root = os.environ.get('DF_TIER_UPGRADE_BACKUP_ROOT') or DEFAULT_TIER_UPGRADE_BACKUP_ROOT
    if not _has_lod_maps(web_map_root):
        print('[tier-upgrade] web/map 下没有找到 lod.json，跳过两档升级检查')
        return
    try:
        tools_dir = os.path.join(HERE, '_dev_tools')
        if tools_dir not in sys.path:
            sys.path.insert(0, tools_dir)
        if not os.path.isfile(os.path.join(tools_dir, 'upgrade_two_tier_layout.py')):
            print('[tier-upgrade] 未附带兼容模块，保留现有地图目录；前端仍兼容旧三档包')
            return
        from upgrade_two_tier_layout import upgrade
        result = upgrade(web_map_root=web_map_root, backup_root=backup_root)
    except Exception as error:  # 升级失败只警告，服务器继续启动
        print('[tier-upgrade] 警告：启动自动升级失败（已忽略，服务器继续启动）：%s: %s'
              % (type(error).__name__, error))
        return
    try:
        upgraded = result.get('upgraded') or []
        skipped = result.get('skipped') or []
        errors = result.get('errors') or []
        seen = result.get('maps_seen', 0)
        if upgraded:
            names = '、'.join(str(item.get('map')) for item in upgraded)
            print('[tier-upgrade] 已把旧三档布局升级为两档 %d 张：%s'
                  '（只改名/重写 lod，未重打包任何 mfpk）' % (len(upgraded), names))
            if result.get('log_path'):
                print('[tier-upgrade] 升级日志：' + str(result['log_path']))
        else:
            print('[tier-upgrade] 已是两档格式，跳过（升级 0 张，未修改任何数据）')
        if seen == 0:
            print('[tier-upgrade] 警告：%s 下没有找到含 lod.json 的地图目录，请检查路径'
                  % web_map_root)
        for item in skipped:
            reason = str(item.get('reason') or '')
            if reason and '已是两档格式' not in reason:
                print('[tier-upgrade] 警告：跳过 %s：%s' % (item.get('map'), reason))
        for item in errors:
            print('[tier-upgrade] 警告：%s 升级失败：%s' % (item.get('map'), item.get('error')))
    except Exception as error:  # 摘要打印本身出错也不能影响启动
        print('[tier-upgrade] 警告：打印升级摘要失败（已忽略）：%s' % error)


WEB_MAP_ROOT = os.path.join(HERE, "web", "map")
TMP_ROOT = os.path.join(HERE, "_tmp")


def _map_codes() -> list:
    try:
        with open(os.path.join(WEB_MAP_ROOT, "map.json"), encoding="utf-8") as fh:
            return [str(m.get("code")) for m in json.load(fh)]
    except Exception:
        return []


def _safe_extract(archive, target: str) -> list:
    names = []
    for info in archive.infolist():
        name = info.filename.replace("\\", "/")
        if name.endswith("/"):
            continue
        if name.startswith("/") or ".." in name.split("/"):
            raise ValueError("非法路径：" + name)
        names.append(name)
    prefix = ""
    tops = {n.split("/")[0] for n in names if "/" in n}
    if len(tops) == 1:
        candidate = next(iter(tops))
        if all(n.startswith(candidate + "/") for n in names):
            prefix = candidate + "/"
    for info in archive.infolist():
        name = info.filename.replace("\\", "/")
        if name.endswith("/"):
            continue
        if prefix:
            if not name.startswith(prefix):
                continue
            rel = name[len(prefix):]
        else:
            rel = name
        if not rel or rel.endswith("/"):
            continue
        dest = os.path.join(target, *rel.split("/"))
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with archive.open(info) as src, open(dest, "wb") as out:
            shutil.copyfileobj(src, out)
    return names


def _copy_missing(src_root: str, dst_root: str):
    added, skipped = [], []
    for base, _dirs, files in os.walk(src_root):
        for name in files:
            full = os.path.join(base, name)
            rel = os.path.relpath(full, src_root)
            dest = os.path.join(dst_root, rel)
            if os.path.exists(dest):
                skipped.append(rel.replace("\\", "/"))
                continue
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(full, dest)
            added.append(rel.replace("\\", "/"))
    return added, skipped


class Handler(http.server.SimpleHTTPRequestHandler):
    def _json(self, payload: dict, status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self) -> None:
        path = self.path.split("?", 1)[0]
        if path == "/api/maps/import":
            self._handle_map_import()
            return
        self.send_error(404)

    def _handle_map_status(self) -> None:
        import urllib.parse
        query = urllib.parse.parse_qs(self.path.split("?", 1)[1]) if "?" in self.path else {}
        code = (query.get("map") or [""])[0].strip()
        if not code or code not in _map_codes():
            self._json({"ok": False, "error": "未知地图：" + code}, 400)
            return
        root = os.path.join(WEB_MAP_ROOT, code)
        required = ["manifest.json", code + "_low.mfpk"]
        missing = [name for name in required if not os.path.isfile(os.path.join(root, name))]
        self._json({"ok": True, "map": code, "installed": not missing, "missing": missing,
                    "root": "web/map/" + code})

    def _handle_map_import(self) -> None:
        import urllib.parse
        query = urllib.parse.parse_qs(self.path.split("?", 1)[1]) if "?" in self.path else {}
        code = (query.get("map") or [""])[0].strip()
        name = (query.get("name") or [""])[0].strip()
        if not code or code not in _map_codes():
            self._json({"ok": False, "error": "未知地图：" + code}, 400)
            return
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            self._json({"ok": False, "error": "空请求体"}, 400)
            return
        if length > 2 * 1024 * 1024 * 1024:
            self._json({"ok": False, "error": "包过大"}, 413)
            return
        os.makedirs(TMP_ROOT, exist_ok=True)
        fd, tmp = tempfile.mkstemp(prefix="map_upload_", dir=TMP_ROOT)
        try:
            with os.fdopen(fd, "wb") as out:
                remaining = length
                while remaining > 0:
                    chunk = self.rfile.read(min(1 << 20, remaining))
                    if not chunk:
                        break
                    out.write(chunk)
                    remaining -= len(chunk)
            target_root = os.path.join(WEB_MAP_ROOT, code)
            os.makedirs(target_root, exist_ok=True)
            if zipfile.is_zipfile(tmp):
                tmp_dir = os.path.join(TMP_ROOT, "map_unzip_" + str(os.getpid()))
                if os.path.isdir(tmp_dir):
                    shutil.rmtree(tmp_dir)
                os.makedirs(tmp_dir, exist_ok=True)
                with zipfile.ZipFile(tmp) as archive:
                    _safe_extract(archive, tmp_dir)
                added, skipped = _copy_missing(tmp_dir, target_root)
                shutil.rmtree(tmp_dir, ignore_errors=True)
            else:
                if not name or not name.lower().endswith(".mfpk") or "/" in name or ".." in name:
                    self._json({"ok": False, "error": "单文件导入需要 name=<文件名>.mfpk"}, 400)
                    return
                dest = os.path.join(target_root, name)
                if os.path.exists(dest):
                    added, skipped = [], [name]
                else:
                    shutil.copy2(tmp, dest)
                    added, skipped = [name], []
            missing = [n for n in ("manifest.json", code + "_low.mfpk") if not os.path.isfile(os.path.join(target_root, n))]
            self._json({"ok": True, "map": code, "added": added, "skipped": skipped,
                        "addedCount": len(added), "skippedCount": len(skipped), "missing": missing})
        except zipfile.BadZipFile:
            self._json({"ok": False, "error": "不是有效的 zip"}, 400)
        except Exception as error:
            self._json({"ok": False, "error": "%s: %s" % (type(error).__name__, error)}, 500)
        finally:
            try:
                os.remove(tmp)
            except OSError:
                pass

    def do_GET(self) -> None:
        if self.path.split("?", 1)[0] == "/api/maps/status":
            self._handle_map_status()
            return

        if self.path.split("?", 1)[0] == "/__install_root":
            body = os.path.realpath(HERE).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        super().do_GET()

    def end_headers(self) -> None:
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        super().end_headers()

    def log_message(self, fmt: str, *args) -> None:
        pass


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def main() -> None:
    _force_utf8_stdio()
    # 绑定端口前先归一化旧精度布局（幂等；新格式下无动作；不重打包任何 mfpk）。
    run_tier_upgrade()
    handler = functools.partial(Handler, directory=HERE)
    try:
        httpd = Server(("127.0.0.1", PORT), handler)
    except OSError as error:
        print(f"端口 {PORT} 已被占用（{error}）。如果浏览器已经能打开 "
              f"http://localhost:{PORT}/web/map.html，说明服务已经在跑了，直接用即可。")
        return
    with httpd:
        print(f"serving {HERE} on http://localhost:{PORT}/web/map.html")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
